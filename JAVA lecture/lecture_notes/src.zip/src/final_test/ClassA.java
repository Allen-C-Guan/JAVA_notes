package final_test;

public class ClassA {
    public int a;
}
