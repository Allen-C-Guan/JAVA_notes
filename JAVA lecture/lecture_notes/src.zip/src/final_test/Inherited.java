package final_test;

public class Inherited extends Base{



    //继承中，子类会自动的继承父类的无参constructor！！！！

    public int addCount() {
        return count++;
    }

}


