package final_test;

public class CharOrStringTest {
    public static void main(String[] args) {
        System.out.println('c'>'d');
    }
}
