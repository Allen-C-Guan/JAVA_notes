package final_test;

public class ClassB {
    public static void ResetA1(ClassA obj){
        obj = new ClassA(); }
    public static void ResetA2(ClassA obj){ obj.a=0;
    } }
